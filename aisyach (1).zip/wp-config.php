<?php
define( 'WP_CACHE', true );

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'kotakuid_wp117' );

/** Database username */
define( 'DB_USER', 'kotakuid_wp117' );

/** Database password */
define( 'DB_PASSWORD', 'pG11(2S0v[' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'd7lv6delbvv45yvc6oxu9x5wpyzduhzh4byecntnmldcjnsogt5wdwgeqjxo947a' );
define( 'SECURE_AUTH_KEY',  'mwq7mbgsl17hmbudnvmdvjvp8wvoeqwoablmzydkzdw0r8aogepupcpuhkgch7tl' );
define( 'LOGGED_IN_KEY',    '0lg3tznq73pzwvrfztejwd48e1nhy7rr0y6fo9md3vsjy5gucmoprjiz2vhzy0aa' );
define( 'NONCE_KEY',        'abjpocfeginznbcoukq2bjjgd1xg3zycxvyrdjupmmtpxqzxfp2cyfz8cvrp77x6' );
define( 'AUTH_SALT',        'c2gqwddjowblcjiesfnlyhruhisln1yqt97y6gpqnfouavn08jzc7jc645pkdqzw' );
define( 'SECURE_AUTH_SALT', 'r0acchnqpxkjvu226ujglfb1ijcrulyvtarsvkb8fljgywahuyu6y9cpvhjvgtom' );
define( 'LOGGED_IN_SALT',   'dvkcu4s83yvntw4mlkmcretd5ezah9illrwap59cdrojxjpgmqtp8vvn3c6feikn' );
define( 'NONCE_SALT',       'kyjjw0vpoqcdyu5hfzhg7zjxhse5akvjrtybzrowsodg0aizitu3vvjarnhwqa4q' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp9h_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
